namespace System
{
   public struct UInt16
   {
   }
}
