namespace System
{
   public abstract class Delegate
   {
   }
}
