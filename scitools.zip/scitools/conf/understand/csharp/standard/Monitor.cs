namespace System.Threading
{
   public static class Monitor
   {
      public static void Enter(object obj);
      public static void Exit(object obj);
   }
}
