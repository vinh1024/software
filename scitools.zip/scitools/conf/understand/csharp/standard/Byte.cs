namespace System
{
   public struct Byte
   {
   }
}
