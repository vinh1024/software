namespace System
{
   public abstract class Enum : ValueType
   {
      protected Enum();
   }
}
