namespace System
{
   public abstract class MemberInfo
   {
      protected MemberInfo();
   }
}
