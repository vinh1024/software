def getpwuid(): pass
def getpwnam(): pass
def getpwall(): pass
