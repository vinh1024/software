import exceptions

class error(exceptions.Exception):
     __weakref__ = []
     
def crop(): pass
def dither2grey2(): pass
def dither2mono(): pass
def grey22grey(): pass
def grey2grey2(): pass
def grey2grey4(): pass
def grey2mono(): pass
def grey2rgb(): pass
def grey42grey(): pass
def mono2grey(): pass
def rgb2grey(): pass
def rgb2rgb8(): pass
def rgb82rgb(): pass
def scale(): pass
def tovideo(): pass
