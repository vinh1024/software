# FUNCTIONS
def warn(): pass
def warn_explicit(): pass

# DATA
default_action = 'default'
filters = []
once_registry = {}
