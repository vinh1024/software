class basestring(object): pass
class buffer(object)
   def __add__(): pass
   def __cmp__(): pass
   def __delitem__(): pass
   def __delslice__(): pass
   def __getattribute__(): pass
   def __getitem__(): pass
   def __getslice__(): pass
   def __hash__(): pass
   def __len__(): pass
   def __mul__(): pass
   def __repr__(): pass
   def __rmul__(): pass
   def __setitem__(): pass
   def __setslice__(): pass
   def __str__(): pass
tbd  lots more
