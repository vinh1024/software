import exceptions

class error(exceptions.Exception):
     __weakref__ = 0

def adler32(): pass
def compress(): pass
def compressobj(): pass
def crc32(): pass
def decompress(): pass
def decompressobj(): pass
DEFLATED = 8
DEF_MEM_LEVEL = 8
MAX_WBITS = 15
ZLIB_VERSION = '1.2.3'
Z_BEST_COMPRESSION = 9
Z_BEST_SPEED = 1
Z_DEFAULT_COMPRESSION = -1
Z_DEFAULT_STRATEGY = 0
Z_FILTERED = 1
Z_FINISH = 4
Z_FULL_FLUSH = 3
Z_HUFFMAN_ONLY = 2
Z_NO_FLUSH = 0
Z_SYNC_FLUSH = 2
__version__ = '1.0'

