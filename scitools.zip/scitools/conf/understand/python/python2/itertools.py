import __builtin__

class chain(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
     from_iterable = 0
     
class combinations(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class combinations_with_replacement(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class compress(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class count(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def __reduce__(): pass
     def __repr__(): pass
     def next(): pass
     __new__ = 0
     
class cycle(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class dropwhile(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class groupby(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class ifilter(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class ifilterfalse(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class imap(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class islice(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class izip(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class izip_longest(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class permutations(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class product(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class repeat(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def __length_hint__(): pass
     def __repr__(): pass
     def next(): pass
     __new__ = 0
     
class starmap(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0
    
class takewhile(__builtin__.object):
     def __getattribute__(): pass
     def __iter__(): pass
     def next(): pass
     __new__ = 0

def tee(): pass


