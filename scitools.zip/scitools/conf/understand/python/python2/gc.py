def collect(): pass
def disable(): pass
def enable(): pass
def get_count(): pass
def get_debug(): pass
def get_objects(): pass
def get_referents(): pass
def get_referrers(): pass
def get_threshold(): pass
def is_tracked(): pass
def isenabled(): pass
def set_debug(): pass
def set_threshold(): pass


DEBUG_COLLECTABLE = 2
DEBUG_INSTANCES = 8
DEBUG_LEAK = 62
DEBUG_OBJECTS = 16
DEBUG_SAVEALL = 32
DEBUG_STATS = 1
DEBUG_UNCOLLECTABLE = 4
garbage = []
