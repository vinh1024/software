package constants

// Target types
const (
	Target_Linux   string = "Linux"
	Target_Windows string = "Windows"
)
