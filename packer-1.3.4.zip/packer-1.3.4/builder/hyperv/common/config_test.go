package common

import (
	"testing"

	"github.com/hashicorp/packer/template/interpolate"
)

func testConfigTemplate(t *testing.T) *interpolate.Context {
	return &interpolate.Context{}
}
